# This code is copied from the file 1.3.r
library(rgdal)
library(sf)
data.Set1.sf <- st_read("set1\\landcover.shp")
data.Set1.cover <- as(data.Set1.sf, "Spatial")
proj4string(data.Set1.cover) <- CRS("+proj=utm +zone=10 +ellps=WGS84")
# End of copied code

proj4string(data.Set1.cover)

st_crs(4326)



############################
# From Bivand code.r
# CRS()
CRS

projargs <- "+proj=utm +zone=10 +ellps=WGS84"
uprojargs <- projargs
doCheckCRSArgs <- TRUE
SRS_string <- NULL
res <- rgdal::checkCRSArgs_ng(uprojargs = uprojargs, 
                    SRS_string = SRS_string)

# checkCRSArgs()
uprojargs1 <- showSRID(uprojargs, format = "PROJ", 
            multiline = "NO")
            
# showSRID()
inSRID <- uprojargs
format <- "PROJ"
multiline <- "NO"
enforce_xy <- NULL
if (format == "PROJ") 
        out_format <- 2L

res <- try(.Call("P6_SRID_show", as.character(inSRID), 
                as.character(format), as.character(multiline), 
                in_format, as.integer(epsg), as.integer(out_format), 
                PACKAGE = "rgdal"), silent = TRUE)
# No error message after this call

################################################
st_crs(data.Set1.sf) <- 32610
st_crs(data.Set1.sf)$proj4string
st_crs(data.Set1.sf)$epsg
st_crs(data.Set1.sf)

data.Albers <- st_transform(data.Set1.sf, crs = 3310)
data.Lambert <- st_transform(data.Set1.sf, crs = 2225)
plot(data.Set1.sf["VegType"], main = "UTM Zone 10N")
plot(data.Albers["VegType"], main = "Albers")
plot(data.Lambert["VegType"])

data(stateMapEnv)
cal.map <- map("state", "california",
   fill=TRUE, col="transparent",  plot = FALSE)
cal.poly <- map2SpatialPolygons(cal.map, "California")
cal.sf <- as(cal.poly, "sf")
st_crs(cal.sf) <- 4326
plot(cal.sf, main = "WGS 84")
cal.Albers <- st_transform(cal.sf, crs = 3310)
plot(cal.Albers)
cal.Lambert <- st_transform(cal.sf, crs = 2225)
plot(cal.Lambert)

CRS(data.Set1.cover)
# For exercises
x <- st_crs(data.Set1.sf)


proj4string(data.Set1.cover)
st_crs(data.Set1.cover)
st_crs(data.Set1.cover)$proj4string
st_crs(data.Set1.cover)$epsg
st_crs(data.Set1.sf)
st_crs(data.Set1.sf)$proj4string
data.Set1.sf$proj4string
st_crs(data.Set1.sf)$epsg

# From https://www.r-spatial.org/r/2020/03/17/wkt.html
library(sf)
st_crs(4326)
x <- st_crs(4326)
x$epsg
x$proj4string
str(x)
x
class(x)
?"$"  # Make this into an Exercise

# From https://link.springer.com/article/10.1007%2Fs10109-020-00336-0

pt1 <- st_point(c(1,1))
pt2 <- pt1 + 1
pt3 <- pt2 + 1
plot(c(pt1, pt2, pt3))



#Exercise

showSRID


##########################
library(sf)
library(raster)
library(spData)
> install.packages('spDataLarge',
  repos='https://nowosad.github.io/drat/', type='source')
vignette(package = "sf")
vignette("sf1")

nc <- st_read(system.file("shape/nc.shp", package="sf"))

par(mar = c(0,0,1,0))
plot(nc[1], reset = FALSE) # reset = FALSE: we want to add to a plot with a legend
plot(nc[1,1], col = 'grey', add = TRUE)

vignette("sf2")
fname <- system.file("shape/nc.shp", package="sf")
fname
nc <- st_read(fname)

vignette("sf3")
geom = st_sfc(st_point(c(0,1)), st_point(c(11,12)))
s = st_sf(a = 15:16, geometry = geom)
st_crs(s)
s1 = s
st_crs(s1) <- 4326
st_crs(s1)

s3 <- s1 %>% st_set_crs(4326) %>% st_set_crs(3857)
# Equivlent to
s3 <- s1
s3 <- st_set_crs(s3, 4326)
s3 <- st_set_crs(s3, 3857)


